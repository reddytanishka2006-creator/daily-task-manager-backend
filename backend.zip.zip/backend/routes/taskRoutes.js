const express = require('express');
const mongoose = require('mongoose');
const Task = require('../models/Task');

const router = express.Router();

/**
 * @route   GET /api/tasks
 * @desc    Fetch all tasks (optional ?status=Pending|Completed)
 * @access  Public
 */
router.get('/', async (req, res) => {
  try {
    const { status, sort = 'createdAt', order = 'desc' } = req.query;
    const filter = {};

    if (status && ['Pending', 'Completed'].includes(status)) {
      filter.status = status;
    }

    const sortOrder = order === 'asc' ? 1 : -1;
    const tasks = await Task.find(filter).sort({ [sort]: sortOrder });

    return res.status(200).json({
      success: true,
      count: tasks.length,
      data: tasks
    });
  } catch (error) {
    console.error('Error fetching tasks:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to retrieve tasks. Please try again later.',
      error: error.message
    });
  }
});

/**
 * @route   POST /api/tasks
 * @desc    Create a new task
 * @access  Public
 */
router.post('/', async (req, res) => {
  try {
    const { title, description, dueDate, status } = req.body;

    // Validate title presence and non-empty string
    if (!title || typeof title !== 'string' || title.trim().length === 0) {
      return res.status(400).json({
        success: false,
        message: 'Task title is required and cannot be empty.'
      });
    }

    // Validate status if provided
    if (status && !['Pending', 'Completed'].includes(status)) {
      return res.status(400).json({
        success: false,
        message: "Status must be either 'Pending' or 'Completed'."
      });
    }

    const newTask = new Task({
      title: title.trim(),
      description: description ? description.trim() : '',
      dueDate: dueDate ? new Date(dueDate) : null,
      status: status || 'Pending'
    });

    const savedTask = await newTask.save();

    return res.status(201).json({
      success: true,
      message: 'Task created successfully.',
      data: savedTask
    });
  } catch (error) {
    console.error('Error creating task:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to create task.',
      error: error.message
    });
  }
});

/**
 * @route   PUT /api/tasks/:id
 * @desc    Update an existing task
 * @access  Public
 */
router.put('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { title, description, dueDate, status } = req.body;

    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid task ID format.'
      });
    }

    // Prepare update payload
    const updates = {};

    if (title !== undefined) {
      if (typeof title !== 'string' || title.trim().length === 0) {
        return res.status(400).json({
          success: false,
          message: 'Task title cannot be empty.'
        });
      }
      updates.title = title.trim();
    }

    if (description !== undefined) {
      updates.description = typeof description === 'string' ? description.trim() : '';
    }

    if (dueDate !== undefined) {
      updates.dueDate = dueDate ? new Date(dueDate) : null;
    }

    if (status !== undefined) {
      if (!['Pending', 'Completed'].includes(status)) {
        return res.status(400).json({
          success: false,
          message: "Status must be either 'Pending' or 'Completed'."
        });
      }
      updates.status = status;
    }

    const updatedTask = await Task.findByIdAndUpdate(
      id,
      { $set: updates },
      { new: true, runValidators: true }
    );

    if (!updatedTask) {
      return res.status(404).json({
        success: false,
        message: 'Task not found.'
      });
    }

    return res.status(200).json({
      success: true,
      message: 'Task updated successfully.',
      data: updatedTask
    });
  } catch (error) {
    console.error('Error updating task:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to update task.',
      error: error.message
    });
  }
});

/**
 * @route   DELETE /api/tasks/:id
 * @desc    Delete a task by ID
 * @access  Public
 */
router.delete('/:id', async (req, res) => {
  try {
    const { id } = req.params;

    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid task ID format.'
      });
    }

    const deletedTask = await Task.findByIdAndDelete(id);

    if (!deletedTask) {
      return res.status(404).json({
        success: false,
        message: 'Task not found.'
      });
    }

    return res.status(200).json({
      success: true,
      message: 'Task deleted successfully.',
      data: { id: deletedTask._id }
    });
  } catch (error) {
    console.error('Error deleting task:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to delete task.',
      error: error.message
    });
  }
});

module.exports = router;
